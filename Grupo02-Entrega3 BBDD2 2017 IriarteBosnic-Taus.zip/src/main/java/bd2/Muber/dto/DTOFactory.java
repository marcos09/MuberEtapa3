package bd2.Muber.dto;

public class DTOFactory {

}
