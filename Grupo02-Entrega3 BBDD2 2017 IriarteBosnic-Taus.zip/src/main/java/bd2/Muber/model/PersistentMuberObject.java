package bd2.Muber.model;

public interface PersistentMuberObject {

}
